﻿using SOAPDemo;
using System;
using System.Threading.Tasks;

namespace AWSAtividade01
{
    class Program
    {
        static async Task Main(string[] args)
        {
            SOAPDemoSoapClient client = new SOAPDemoSoapClient();
            var response1 = await client.DivideIntegerAsync(10, 2);

            Console.WriteLine($"DivideIntegerAsync 10/2: {response1}");
            
            var response2 = await client.AddIntegerAsync(1,1);

            Console.WriteLine($"AddIntegerAsync 1+1: {response2}");
            
            var response3 = await client.FindPersonAsync("1");

            Console.WriteLine($"FindPersonAsync id 1: {response3.Name}");
            Console.ReadLine();

        }
    }
}
